﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schedulefy.ViewModels.Events
{
    public class IndexEventViewModel : BaseEventViewModel
    {
        public int GoingCount { get; set; }
    }
}
